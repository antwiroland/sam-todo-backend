import boto3
import os
import json
from boto3.dynamodb.conditions import Key

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(os.environ["TABLE_NAME"])

def build_response(status_code, body):
    """Build HTTP response with CORS headers"""
    return {
        'statusCode': status_code,
        'headers': {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,X-Amz-User-Agent',
            'Access-Control-Allow-Credentials': 'true'
        },
        'body': json.dumps(body)
    }

def lambda_handler(event, context):
    print("=== TODO API CALLED ===")
    print("HTTP Method:", event.get('httpMethod'))
    print("Path:", event.get('path'))
    print("Full Event:", json.dumps(event, indent=2))
    
    # Handle CORS preflight OPTIONS request
    if event.get('httpMethod') == 'OPTIONS':
        print("Handling CORS preflight request")
        return build_response(200, {'message': 'CORS preflight'})
    
    # Extract user from Cognito authorizer
    if 'requestContext' in event and 'authorizer' in event['requestContext']:
        claims = event['requestContext']['authorizer']['claims']
        user_id = claims["sub"]
        user_email = claims.get("email")
        print(f"User authenticated: {user_id}")
    else:
        print("No authorizer found in request")
        return build_response(401, {'error': 'No authentication data'})
    
    method = event["httpMethod"]
    path = event["path"]

    try:
        if method == "GET" and path == "/tasks":
            # Get all tasks for user
            print(f"Fetching tasks for user: {user_id}")
            response = table.query(
                KeyConditionExpression=Key("UserId").eq(user_id)
            )
            print(f"Found {len(response['Items'])} tasks")
            
            return build_response(200, {
                'message': 'Tasks retrieved successfully',
                'tasks': response['Items']
            })

        elif method == "POST" and path == "/tasks":
            # Create new task
            body = json.loads(event["body"])
            task_id = body.get("TaskId")
            task_name = body.get("TaskName")
            
            print(f"Creating task: {task_name} with ID: {task_id}")
            
            if not task_id or not task_name:
                return build_response(400, {'error': 'TaskId and TaskName are required'})

            # Create task item
            task_item = {
                "UserId": user_id,
                "TaskId": task_id,
                "TaskName": task_name,
                "Status": "Pending",
                "UserEmail": user_email,
                "CreatedAt": context.aws_request_id
            }
            
            table.put_item(Item=task_item)
            
            return build_response(201, {
                'message': 'Task created successfully',
                'task': task_item
            })

        elif method == "PUT" and path == "/tasks":
            # Update task
            body = json.loads(event["body"])
            task_id = body.get("TaskId")
            new_status = body.get("Status")
            new_name = body.get("TaskName")

            print(f"Updating task: {task_id}")

            if not task_id:
                return build_response(400, {'error': 'TaskId is required'})

            update_expression = []
            expression_values = {}

            if new_status:
                update_expression.append("Status = :s")
                expression_values[":s"] = new_status
            if new_name:
                update_expression.append("TaskName = :n")
                expression_values[":n"] = new_name

            if not update_expression:
                return build_response(400, {'error': 'Nothing to update'})

            table.update_item(
                Key={"UserId": user_id, "TaskId": task_id},
                UpdateExpression="SET " + ", ".join(update_expression),
                ExpressionAttributeValues=expression_values
            )

            return build_response(200, {'message': f'Task {task_id} updated successfully'})

        elif method == "DELETE" and path == "/tasks":
            # Delete task
            body = json.loads(event["body"])
            task_id = body.get("TaskId")

            print(f"Deleting task: {task_id}")

            if not task_id:
                return build_response(400, {'error': 'TaskId is required'})

            table.delete_item(
                Key={"UserId": user_id, "TaskId": task_id}
            )

            return build_response(200, {'message': f'Task {task_id} deleted successfully'})

        else:
            return build_response(404, {'error': 'Endpoint not found'})

    except Exception as e:
        print(f"Error: {str(e)}")
        return build_response(500, {'error': f'Internal server error: {str(e)}'})